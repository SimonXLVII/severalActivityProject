package com.example.severalactivities

import android.content.Intent
import android.graphics.drawable.DrawableContainer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import com.example.severalactivities.databinding.ActivityActiv2Binding
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ListView
import androidx.cardview.widget.CardView


class activ2 : AppCompatActivity() {
    private lateinit var binding: ActivityActiv2Binding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityActiv2Binding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        val arguments = intent.extras
        var txt: String = "default"
        if(arguments!=null) {
            txt = arguments.get("txt").toString()
        }
        binding.textView2.text = binding.textView2.text.toString()+", "+txt

        val btn_toact2 = binding.buttonToact2
        btn_toact2.setOnClickListener{
            val act1_start = Intent(this, MainActivity::class.java)
            startActivity(act1_start)
        }

        val sleepwalker: ImageView = binding.sleepwalker
        val sleepwalkerAnimation: Animation = AnimationUtils.loadAnimation(this, R.anim.move_sw)

        sleepwalker.startAnimation(sleepwalkerAnimation)
        sleepwalker.animate().rotation(360F)
        sleepwalker.animate().duration = 5555

        binding.textView2.startAnimation(sleepwalkerAnimation)
        binding.textView2.animate().rotation(360F)
        binding.textView2.animate().duration = 5555
    }
}
